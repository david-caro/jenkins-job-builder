echo "Here ->{myvar}<- you should see nothing"
