#!/bin/bash
echo "Doing somethiung cool"
