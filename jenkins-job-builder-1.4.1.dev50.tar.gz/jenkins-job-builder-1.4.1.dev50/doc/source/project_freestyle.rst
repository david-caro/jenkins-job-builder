.. _project_freestyle:

Freestyle Project
=================

.. automodule:: project_freestyle
   :members:
