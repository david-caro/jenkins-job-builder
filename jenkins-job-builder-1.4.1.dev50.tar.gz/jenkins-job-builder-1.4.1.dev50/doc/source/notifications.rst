.. _notifications:

Notifications
=============

.. automodule:: notifications
   :members:
